import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Category } from '../category';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  [x: string]: any;
url:string="http://localhost:3000/categories";
filterdata:Category[];
  constructor(private http:HttpClient) { }
  addCategory(category:Category){
    return this.http.post(this.url,category);
  }
  updateCategory(category:Category) {
    return this.http.put(this.url+"/"+category.name,category);
  }
  deleteCategory(category:Category){
    return this.http.delete<Category[]>(this.url+"/"+category.name);
  }
  getAllCategory() {
    return this.http.get<Category[]>(this.url);
  }
}
