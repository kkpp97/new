import { Component, OnInit } from '@angular/core';

import { CategoryService } from 'src/app/Category/category.service';
import { Category } from 'src/app/Category';

@Component({
  selector: 'app-categorylist',
  templateUrl: './categorylist.component.html',
  styleUrls: ['./categorylist.component.css']
})
export class CategorylistComponent implements OnInit {
categories:Category[];
  constructor(private categoryService:CategoryService) { }

  ngOnInit() {
    this.categoryService.getAllCategory().subscribe((data:Category[])=>{this.categories=data
      console.log("all"+this.categories)});
  }
  deleteCategory(category:Category){
    this.categoryService.deleteCategory(category).subscribe(
    (data)=>{this.categories=this.categories.filter(c=>c!==category)}
    );
  }


}
