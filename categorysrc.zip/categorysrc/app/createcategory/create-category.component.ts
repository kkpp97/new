import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../Category/category.service';
import { Router } from '@angular/router';
import { Category } from '../category';

@Component({
  selector: 'app-create-category',
  templateUrl: './create-category.component.html',
  styleUrls: ['./create-category.component.css']
})
export class CreateCategoryComponent implements OnInit {
categoryData:Category={"id":0,"name":''};
  constructor(private categoryService:CategoryService,private router:Router) { }

  ngOnInit() {
  }
  CreateNewCategory(){
    console.log(this.categoryData.name);
    this.categoryService.addCategory(this.categoryData).subscribe((data)=>this.router.navigate(['Categorylist']));
  }

}
