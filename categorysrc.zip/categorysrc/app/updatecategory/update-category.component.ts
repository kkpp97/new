import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../Category/category.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Category } from '../category';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit {
categoryData:Category={"id":0,"name":''};
  constructor(private categoryService:CategoryService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
  
  }
Edit(){
  console.log(this.categoryData.name);
  this.categoryService.updateCategory(this.categoryData).subscribe((data)=>{this.router.navigate(['listcategory'])});
}
}
