package UserInfo;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},monochrome=true,
					features= {"C:/Users/karkovvu/Downloads/UserInformation/src/test/resources/UserInformation/UserInfo.feature"},
					glue= {"UserInfo"})
public class UserRunner {

}
